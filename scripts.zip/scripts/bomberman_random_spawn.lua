math.randomseed(os.time())

local END_VIVOS = 0x1EA0

local spawns = {
    {32, 48},
    {223, 207},
    {223, 48},
    {32, 207},
    {127, 128}
}

local ultimoVivos = memory.read_u8(END_VIVOS, "WRAM")

local function shuffle(t)
    for i = #t, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
end

local function aplicarSpawns()

    shuffle(spawns)

    memory.write_u16_le(0x0312, spawns[1][1], "WRAM")
    memory.write_u16_le(0x0316, spawns[1][2], "WRAM")

    memory.write_u16_le(0x0412, spawns[2][1], "WRAM")
    memory.write_u16_le(0x0416, spawns[2][2], "WRAM")

    memory.write_u16_le(0x0512, spawns[3][1], "WRAM")
    memory.write_u16_le(0x0516, spawns[3][2], "WRAM")

    memory.write_u16_le(0x0612, spawns[4][1], "WRAM")
    memory.write_u16_le(0x0616, spawns[4][2], "WRAM")

    memory.write_u16_le(0x0712, spawns[5][1], "WRAM")
    memory.write_u16_le(0x0716, spawns[5][2], "WRAM")

    console.log("Spawns embaralhados!")
end

while true do

	gui.text(10, 10, "SCRIPT ATIVO")

    local vivos = memory.read_u8(END_VIVOS, "WRAM")

    -- Nova rodada começou
    if vivos > ultimoVivos then
        aplicarSpawns()
    end

    ultimoVivos = vivos

    emu.frameadvance()
end
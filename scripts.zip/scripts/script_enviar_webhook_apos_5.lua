local URL = "https://crown-cup-champions.lovable.app/api/public/match-result"

local ultimo = {
    p1 = memory.read_u16_le(0x1F34, "WRAM"),
    p2 = memory.read_u16_le(0x1F36, "WRAM"),
    p3 = memory.read_u16_le(0x1F38, "WRAM"),
    p4 = memory.read_u16_le(0x1F3A, "WRAM"),
    p5 = memory.read_u16_le(0x1F3C, "WRAM")
}

local function enviarWebhook(p1, p2, p3, p4, p5)
    local payload = string.format(
        '{"p1":%d,"p2":%d,"p3":%d,"p4":%d,"p5":%d}',
        p1, p2, p3, p4, p5
    )
    local f = io.open("payload.json", "w")
    f:write(payload)
    f:close()

    local comando =
        'start /b curl -s -X POST "' .. URL .. '" ' ..
        '-H "Content-Type: application/json" ' ..
        '-d @payload.json'
    console.log("Enviando placar final: " .. payload)
    os.execute(comando)
end

while true do
    local p1 = memory.read_u16_le(0x1F34, "WRAM")
    local p2 = memory.read_u16_le(0x1F36, "WRAM")
    local p3 = memory.read_u16_le(0x1F38, "WRAM")
    local p4 = memory.read_u16_le(0x1F3A, "WRAM")
    local p5 = memory.read_u16_le(0x1F3C, "WRAM")

    -- só envia quando alguém chegar a 5
    if p1 == 5 or p2 == 5 or p3 == 5 or p4 == 5 or p5 == 5 then
        -- evita ficar reenviando enquanto o placar não mudar
        if p1 ~= ultimo.p1
            or p2 ~= ultimo.p2
            or p3 ~= ultimo.p3
            or p4 ~= ultimo.p4
            or p5 ~= ultimo.p5 then
            enviarWebhook(p1, p2, p3, p4, p5)
            ultimo.p1 = p1
            ultimo.p2 = p2
            ultimo.p3 = p3
            ultimo.p4 = p4
            ultimo.p5 = p5
        end
    end

    emu.frameadvance()
end